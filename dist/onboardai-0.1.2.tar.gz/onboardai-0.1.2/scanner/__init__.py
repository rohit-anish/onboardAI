# OnboardAI scanner module
